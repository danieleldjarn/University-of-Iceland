import unittest
import fall


class testkapall(unittest.TestCase):
    def test_veldi(self):
        self.assertEqual(fall.veldi(1), 1)
if __name__ == '__main__':
	unittest.main(verbosity=2, exit=False)
class testkapall(unittest.TestCase):
    def test_veldi(self):
        self.assertEqual(fall.veldi(2), 4)
if __name__ == '__main__':
	unittest.main(verbosity=2, exit=False)
class testkapall(unittest.TestCase):
    def test_veldi(self):
        self.assertEqual(fall.veldi(3), 9)
if __name__ == '__main__':
	unittest.main(verbosity=2, exit=False)
class testkapall(unittest.TestCase):
    def test_veldi(self):
        self.assertEqual(fall.veldi(5), 25)
if __name__ == '__main__':
	unittest.main(verbosity=2, exit=False)
class testkapall(unittest.TestCase):
    def test_veldi(self):
        self.assertEqual(fall.veldi(10), 100)
if __name__ == '__main__':
	unittest.main(verbosity=2, exit=False)
