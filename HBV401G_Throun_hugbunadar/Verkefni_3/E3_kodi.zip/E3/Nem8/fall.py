# -*- coding: cp1252 -*-
#bj� h�r til fall til a� setja � unittest, veldi hefur ekkert a� gera me� kapalinn.
def veldi(s):
    k=s**2
    return k
