# Her er buinn til klasi fyrir spilin

class Spil: 
    
    def __init__(self,sort,numer):
        self.numer = numer
        self.sort = sort
        
    def sjaSpil(self):
        print str(self.sort) + ' ' + str(self.numer)
        return str(self.sort) + ' ' + str(self.numer)

    
    
        
